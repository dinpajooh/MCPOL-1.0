#!/bin/bash

BD=$PWD

for ((K=1;K<=50;K++)); do
    cd $BD/anly
    cp ../traj$K.dat traj.dat
    SLT < anly_input > OUT$K
    mv gk.dat gk$K.dat
    mv sk.dat sk$K.dat
done





exit
