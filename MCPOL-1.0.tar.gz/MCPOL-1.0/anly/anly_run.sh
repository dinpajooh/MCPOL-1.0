#!/bin/bash

BD=$PWD

for dir in a0.02; do
    cd $BD/$dir
    ./SLT < anly_input > ANLY_OUT &
done


exit

