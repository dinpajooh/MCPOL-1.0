#!/bin/bash

BD=$PWD
cd $BD
rm -rf final
mkdir final

for ((K=1;K<=50;K++)); do

    cat chi$K.dat | awk '{print $1 "   " $4 }'  > $BD/final/rk_chiLn$K.dat
    cat chi$K.dat | awk '{print $1 "   " $5 }'  > $BD/final/rk_chiTn$K.dat
    cat chi$K.dat | awk '{print $1 "   " $6 }'  > $BD/final/rk_chiLe$K.dat
    cat chi$K.dat | awk '{print $1 "   " $7 }'  > $BD/final/rk_chiTe$K.dat
    cat chi$K.dat | awk '{print $1 "   " $8 }'  > $BD/final/rk_chiLen$K.dat
    cat chi$K.dat | awk '{print $1 "   " $9 }'  > $BD/final/rk_chiTen$K.dat

done

for ((K=1;K<=50;K++)); do
    ypol=$(grep 'ypol=(4pi/9)' OUT$K | awk '{print $3}')
    ypolmprsq=$(grep 'yeff=yp+ye' OUT$K | awk '{print $1}')
    p2tot=$(grep '< <p>^2 > obtained' OUT$K | awk '{print $8}')
    sed '$d' < OUT$K > tmp ; mv tmp board
    mprmsq=$(awk 'END{print}' board)
    echo $ypol $ypolmprsq $mprmsq  $p2tot  >> final/OUTALL
done
rm board



exit

