#!/bin/bash

BD=$PWD
cd $BD
f95 -o SLT structure_alpha3.f90

mkdir a0.02

for dir in a0.02; do
    cp $BD/SLT        $BD/$dir
    cp $BD/anly_input $BD/$dir
done


exit

