#!/bin/bash

# 1- Generate the executable rdfavg from avgfiles.f  
# 2- RUN ./avg_SKs.sh
#Set up a base directory
BD=$PWD

cd $BD

ifort -o skavg avgfiles_SKs.f 

rm -rf SK_final
mkdir SK_final
cp skavg SK_final


for ((K=1;K<=50;K++)); do
     cp $BD/rk_chiLn$K.dat    $BD/SK_final/$K
done
cd $BD/SK_final
./skavg
mv final rk_chiLn.dat
for ((K=1;K<=50;K++)); do
     rm -rf $K
done


for ((K=1;K<=50;K++)); do
     cp $BD/rk_chiTn$K.dat    $BD/SK_final/$K
done
cd $BD/SK_final
./skavg
mv final rk_chiTn.dat
for ((K=1;K<=50;K++)); do
     rm -rf $K
done

for ((K=1;K<=50;K++)); do
     cp $BD/rk_chiLe$K.dat    $BD/SK_final/$K
done
cd $BD/SK_final
./skavg
mv final rk_chiLe.dat
for ((K=1;K<=50;K++)); do
     rm -rf $K
done


for ((K=1;K<=50;K++)); do
     cp $BD/rk_chiTe$K.dat    $BD/SK_final/$K
done
cd $BD/SK_final
./skavg
mv final rk_chiTe.dat
for ((K=1;K<=50;K++)); do
     rm -rf $K
done


for ((K=1;K<=50;K++)); do
     cp $BD/rk_chiLen$K.dat    $BD/SK_final/$K
done
cd $BD/SK_final
./skavg
mv final rk_chiLen.dat
for ((K=1;K<=50;K++)); do
     rm -rf $K
done


for ((K=1;K<=50;K++)); do
     cp $BD/rk_chiTen$K.dat    $BD/SK_final/$K
done
cd $BD/SK_final
./skavg
mv final rk_chiTen.dat
for ((K=1;K<=50;K++)); do
     rm -rf $K
done



cd $BD
ifort -o yavg avgy.f90
./yavg > $BD/SK_final/AVGs

cd $BD/SK_final
rm -rf skavg

exit
